ALTER TABLE Listings
RENAME TO Listing;

ALTER TABLE Reviews
RENAME TO Review;

ALTER TABLE Neighbourhoods
RENAME TO Neighbourhood;

ALTER TABLE Listings_Summary
RENAME TO Listing_Summary;

ALTER TABLE Reviews_Summary
RENAME TO Review_Summary;