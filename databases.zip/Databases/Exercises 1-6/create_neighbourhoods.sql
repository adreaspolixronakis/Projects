create table "Neighbourhoods"(
   neighbourhood_group varchar(10),
   neighbourhood varchar(1000) PRIMARY KEY
);