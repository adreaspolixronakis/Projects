import java.util.*;
public class PublisherNode implements Publisher{
	public void push(Artistname an,Value v){
		Queue<Value> q = new LinkedList<>();
		q.add(v);
	}
}
		
	