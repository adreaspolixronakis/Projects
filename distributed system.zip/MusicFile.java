import java.util.*;
public class MusicFile{
	 String trackName;
	 String artistName;
	 String albumInfo;
	 String genre;
	 byte[] musicFileExtract;
}