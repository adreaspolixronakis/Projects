import java.util.*;
import java.io.*;
import java.text.*;
import java.net.*;
import java.math.*;
public class Publisher extends Node{
	public void getBrockerList(){}
		
	public Broker hashTopic(ArtistName an){
		BigInteger b1, b2;
	}
	public void push(Artistname an,Value v);
	public void notifyFailure(Brocker b){
		int count=0;
		for (int i = 0; i < brokers.size(); i++) {
			if(brokers.get(i)==b){
				System.out.println("exist");
				count++;
			}
			if(count==0)
				System.out.println("not exist");
		}
	}
		public static void main(String args[]){
		}			
}

	