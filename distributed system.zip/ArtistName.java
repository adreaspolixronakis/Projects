import java.util.*;
public class ArtistName{
	String artistName;
}