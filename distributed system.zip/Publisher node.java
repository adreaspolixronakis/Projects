public class Publisher node extends Publisher{
	
	