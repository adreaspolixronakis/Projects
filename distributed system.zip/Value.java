import java.util.*;
public class Value{
	MusicFile musicFile;
}