/*set a color in the header*/
function myfunc1(){
  document.querySelector("h1").style.backgroundColor = "lightblue";
}
function myfunc2() {
  document.querySelector("h2").innerHTML = "Penetration testing, also called pen testing or ethical hacking, is the practice of testing a computer system, network or web application to find security vulnerabilities that an attacker could exploit.Penetration testing can be automated with software applications or performed manually.";
  
}


function myfunc3() {
  document.getElementById("footer").style.backgroundColor = "lightblue";
  document.getElementById("footer").style.fontSize = "large";
}
function image(){
document.body.style.backgroundImage="url(prog1.png)";
document.body.style.fontSize="medium";
}

function changeimage(){
document.getElementById("img").src ="prog.gif"; 
}
function mymain(){
var x = document.getElementsByClassName("p1");
var i;
for (i = 0; i < x.length; i++) {
x[i].style.fontSize = "medium";
}
}



var d = new Date();
function myfunc4(){
if(d.getDay()=="0"){
  document.querySelector("h3").innerHTML = "Σήμερα είναι:Κυριακή<br>"+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
                                           "Καλή βδομάδα"

  document.getElementById("img").src ="pentest7.png";
  document.body.style.backgroundColor="lightskyblue";

}else if(d.getDay()=="1"){
  document.querySelector("h3").innerHTML = "Σήμερα είναι:Δευτέρα <br>"+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
                                            
                                            document.body.style.backgroundColor="lightskyblue";
                                            document.getElementById("img").src="prog.gif"; 
}else if(d.getDay()=="2"){
  document.querySelector("h3").innerHTML = "Σήμερα είναι:Τρίτη";+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
                          document.getElementById("img").src="pentest7.png"; 
document.body.style.backgroundColor="red";
}else if(d.getDay()=="3"){
  document.querySelector("h3").innerHTML = "Σήμερα είναι:Τετάρτη";+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
                                                                               
document.body.style.backgroundColor="lightskyblue";
document.getElementById("img").src="pentest3.png"; 

}else if(d.getDay()=="4"){
document.querySelector("h3").innerHTML = "Σήμερα είναι:Πέμπτη <br>"+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
                                           
document.getElementById("img").src ="pentest7.png"; 
document.body.style.backgroundColor="lightgreen";
                                             
                                            
}else if(d.getDay()=="5"){
  document.querySelector("h3").innerHTML = "Σήμερα είναι:Παρασκευή";+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
                                            +d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
 document.getElementById("img").src ="pentest7.png";
 document.body.style.backgroundColor="lightgreen";

}else if(d.getDay()=="6"){
  document.querySelector("h3").innerHTML ="Σήμερα είναι:Σάββατο";+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
                                           
                                           document.body.style.backgroundColor="lightgreen";

}
}
function english() {
document.getElementById("p2").innerHTML = "Definition of PenTesting"
document.getElementById("p1").innerHTML = "A penetration test also known as PenTesting is a controlled attack on computer software aimed at finding vulnerabilities and vulnerabilities to gain unauthorized access to system functions and data.";
document.getElementById("p3").innerHTML = "Target of pentesting";
document.getElementById("p4").innerHTML = "The aim of PenTesting is: a) The correction of errors that may exists b) The risk assessment c) The risk reduction andd) Increasing the security of information systems.";
document.getElementById("p5").innerHTML="In which branch does it belong:"
document.getElementById("p6").innerHTML="PenTesting is part of the Security industry of Information Systems and are an integral part of a security audit."
document.getElementById("p7").innerHTML="A link to the wikipedia of Penetration Testing can be found here:"
}

function english2(){
document.getElementById("p2").innerHTML = "CONTROLS-STAGES IN PENTESTING:"
document.getElementById("p3").innerHTML = "Types of Tests in PenTesting:"
document.getElementById("p1").innerHTML = "There are two main types of tests in PenTesting: the external black box test or the white box internal test.This separation is made depending on the background and the information provided in advance to the responsible auditor. More specifically,the black box method provides little to no information,while unlike the white box method I provide complete knowledge. There is even the gray box method which is a combination of both. In the gray box method the limited knowledge of the target is notified to the auditor.So summarizing a penetration test can help identify the vulnerability of a system during an attack to assess whether it is vulnerable.";
document.getElementById("p5").innerHTML="Stages of PenTesting";
document.getElementById("p8").innerHTML="Collection of information"
document.getElementById("p6").innerHTML="Its purpose is to find phishing entry point spear phising etc and is done with various tools. A tool which NMAP is widely used and is well known.Nmap is basically an Open source tool that is used for both crawling and network mapping.Also, the collection of information can be done with Social Engineering.Social engineering is essentially an act that aims to manipulate a person in the interest of the attacker and can be done in various ways such as misleading e-mails.";
document.getElementById("p9").innerHTML="Detection of vulnerabilities"
document.getElementById("p10").innerHTML="The goal of this stage is to find them system weaknesses. There are two ways to control the automated control and the manual control.Automated control is essentially done with various tools such as Nesus, Burp, Netsparker and is performed with a command script.Manual control, on the other hand, is a control that is performed manually without the use of any specialized tools.In essence, in the detection of vulnerabilities, the target is checked for all possible and known vulnerabilities. The detection of vulnerabilities is done with CVSS.There are two types of audits that can be performed. The first audit is external and the second audit is internal.Vulnerabilities are detected on the external control as an external observer, while internally as a user or system administrator (eg databases)."
document.getElementById("p11").innerHTML="CONTROLLED ATTACK:";
document.getElementById("p12").innerHTML="A controlled attack is called exploiting design vulnerabilities or vulnerabilities in the system or software to gain unauthorized access to protected system resources or data.There are 2 ways to do the controlled attack. The first way is the vertical scaling and the second way is the horizontal scaling.In vertical scaling, users with fewer rights gain access to resources or data, and this is done as there are problems at the core of operating systems.In horizontal scaling, a single user can access functions or content for ordinary users such as a file.";
document.getElementById("p13").innerHTML="PenTesting consists of several stages.<br> 1) Information Collection <br> 2) Information Analysis and Design <br> 3) Vulnerability Detection <br>  4) Controlled Attack <br> 5) Cleaning and extraction.<br> These are the basic stages of a PentTesting but in the stages in which you will focus and give more basis is information gathering, vulnerability detection and Controlled Attack.More details <br>";
}

function english3(){
document.getElementById("p2").innerHTML = "EXPERIENCE IN PENTESTING:";
document.getElementById("p3").innerHTML = "Personal experience:";
document.getElementById("p1").innerHTML = "I dealt with PenTesting in the 7th semester as part of the course:Information Systems Security. This course gave me the opportunity to deal with and Gain a basic knowledge on computer security that it will be very useful in my future career";
}
//ASKISI 8//
//--------------------------------------------//

//validate lastname
window.onload=function(){
var lastname=document.getElementById("lastname");
console.log(lastname.value)
lastname.addEventListener('input',()=>{
  lastname.setCustomValidity('');
  lastname.checkValidity();
});

lastname.addEventListener('invalid',()=>{
  if(lastname.value===''){
    lastname.setCustomValidity("Δώστε το ονοματεπώνυμό σας");
  }else{
    lastname.setCustomValidity("Δώστε το ονοματεπώνυμό σας με ελληνικούς χαρακτήρες");
  }
});






//validate username
var username=document.getElementById("username");
username.addEventListener('input',()=>{
  username.setCustomValidity('');
  username.checkValidity();
});

username.addEventListener('invalid',()=>{
  if(username.value===''){
    username.setCustomValidity("Δώστε το username σας");
  }else{
    username.setCustomValidity("Δώστε το username σας ως εξής:Με λατινικους χαρακτήρες κεφαλαία ή πεζά και μπορείτε να χρησιμοποιήσετε και αριθμούς χωρίς κενό ενδιάμεσα");

  }
});






//validate password
var pass=document.getElementById("password");
var passConf=document.getElementById("confirm_password");

pass.addEventListener('input', () => {
  pass.setCustomValidity('');
  pass.checkValidity();
});

pass.addEventListener('invalid', () =>{
  if(pass.value == ''){
    pass.setCustomValidity('Πληκτρολογήστε τον κωδικό σας')
  }
});

passConf.addEventListener('input', () => {
  passConf.setCustomValidity('');
  passConf.checkValidity();
});

passConf.addEventListener('invalid', () => {
  if(passConf.value ==''){
      passConf.setCustomValidity("Επιβεβαιώστε τον κωδικό σας");
  }else{
    password.onchange = check;
    confirm_password.onkeyup =check;
  }
});


function check(){
  if(pass.value != passConf.value){
    passConf.setCustomValidity('Οι κωδικοί δεν ταιριάζουν προσπαθήστε ξανά');
  }else{
    passConf.setCustomValidity('');
  }
}

/*function validatePassword(){
  var password = document.getElementById("password")
  , confirm_password = document.getElementById("confirm_password");
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}*/

//validate telephone

var telephone=document.getElementById("telephone");
telephone.addEventListener('input',()=>{
  telephone.setCustomValidity('');
  telephone.checkValidity();
});
telephone.addEventListener('invalid',()=>{
  if(telephone.value===''){
    telephone.setCustomValidity("Δώστε το τηλέφωνό σας");
  }else{
    telephone.setCustomValidity("οι αριθμοί πρέπει να είναι 10");

  }
});





//validate city
var city=document.getElementById("city");
city.addEventListener('input',()=>{
  city.setCustomValidity('');
  city.checkValidity();
});
city.addEventListener('invalid',()=>{
  if(city.value===''){
  city.setCustomValidity("Δώστε την πόλη σας");
  }else{
  city.setCustomValidity("Απαγορεύονται οι αγγλικοί χαρακτήρες και το κενό");  
  }
  
});

//validate address
var address=document.getElementById("address");
address.addEventListener('input',()=>{
  address.setCustomValidity('');
  address.checkValidity();
});
address.addEventListener('invalid',()=>{
  if(address.value===''){
  address.setCustomValidity("Δώστε την διεύθυνσή σας");
  }else{
  address.setCustomValidity("οι χαρακτήρες πρέπει να ναι στα Ελληνικά (κενό) και τον αριθμό.Όπως φαίνεται στο παράδειγμα");  
  }
  
});
//validate Date
var date=document.getElementById("number");
date.addEventListener('input',()=>{
  date.setCustomValidity('');
  date.checkValidity();
});
date.addEventListener('invalid',()=>{
  if(date.value===''){
  date.setCustomValidity("Πληκτρολογήστε την ημερομηνία γεννήσεώς σας");
  }
  date.onchange=validateDate;

  
});


function validateDate(){
  var birthday=document.getElementById("number");
  var birth=new Date(birthday.value);
  if((d.getFullYear()-birth.getFullYear())<18){
    birthday.setCustomValidity("Πρέπει να είστε ενήλικας ");
  }else{
    birthday.setCustomValidity("");
  }
}

//validate region
var region=document.getElementById("region");
region.addEventListener('input',()=>{
  region.setCustomValidity('');
  region.checkValidity();
});
region.addEventListener('invalid',()=>{
  if(region.value===''){
  region.setCustomValidity("Πληκτρολογήστε την περιοχή σας");
  }else{
    region.setCustomValidity("Μολις πληκτρολογήσετε την περιοχή σας πατήσε το 'space'(Οι χαρακτήρες πρέπει να είναι στα Ελληνικά) ");
  }
 });


}