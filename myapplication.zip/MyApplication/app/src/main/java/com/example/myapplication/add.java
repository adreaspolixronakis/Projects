package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class add extends AppCompatActivity {
    static TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);
        Log.i("create", "create add activity");
        result = findViewById(R.id.result2);
        Intent intent = getIntent();
        String str = intent.getStringExtra("message");
        result.setText("The result is :"+str);
    }

    protected void onResume() {
        super.onResume();
        Log.i("resume", "resume add activity");
    }

    public void back(View view){
        Intent intent= new Intent(add.this,MainActivity.class);
        intent.putExtra("message","");
        this.startActivity(intent);
    }
    public void onBackPressed (){
        Log.i("back", "Returning to Homescreen....");
        Intent intent= new Intent(add.this,MainActivity.class);
        intent.putExtra("message","");
        this.startActivity(intent);
    }

    protected void onPause() {

        super.onPause();
        Log.i("pause", "pause add activity");

    }

    protected void onStop() {

        super.onStop();
        Log.i("stop","stop add activity");

    }
    protected void onRestart() {

        super.onRestart();
        Log.i("restart", "restart add activity");

    }
    protected void onDestroy() {
        super.onDestroy();
        Log.i("destroy", "destroy add activity");

    }


}
