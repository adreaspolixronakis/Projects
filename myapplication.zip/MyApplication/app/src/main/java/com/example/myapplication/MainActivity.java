package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText number1;
    EditText number2;
    Button addbutton;
    TextView result;
    static int sum=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("create", "create main activity");
        number1 = findViewById(R.id.first);
        number2 = findViewById(R.id.second);
        addbutton = findViewById(R.id.sumbutton);
        if(number1.getText().toString().trim().equals("")){
            //number1.setError("A number is required");
            number1.setHint("Enter a first number");

        }
        if(number2.getText().toString().trim().equals("")){
           // number2.setError("A number is required");
            number2.setHint("Enter a second number");

        }


    }

    @Override
    protected void onResume() {

        super.onResume();
    Log.i("resume","resume main activity");
      //  if(number1!=null){
            number1.setText("");
        //}
       // if(number2!=null){
            number2.setText("");
       // }
        if(number1.getText().toString().trim().equals("")){
            //number1.setError("A number is required");
            number1.setHint("Enter a first number");

        }
        if(number2.getText().toString().trim().equals("")){
            //number2.setError("A number is required");
            number2.setHint("Enter a second number");

        }

    }
    @Override

    protected void onPause() {

        super.onPause();
        Log.i("pause", "pause main activity");

    }

    protected void onStop() {

        super.onStop();
        Log.i("stop","stop main activity");

    }
    protected void onRestart() {

        super.onRestart();
        Log.i("restart", "restart main activity");

    }
    protected void onDestroy() {
        super.onDestroy();
        Log.i("destroy", "destroy main activity");

    }
    public void onBackPressed (){
        Log.i("back", "Closing the app....");
    }




    public void add (View view){
        addbutton = findViewById(R.id.sumbutton);
            boolean f1=true;
            boolean f2=true;
            sum=0;
            int num1;
            int num2;
            while(f1 && f2) {
                number1 = findViewById(R.id.first);
                number2 = findViewById(R.id.second);
                if (!(number1.getText().toString().trim().equals(""))) {
                     num1 = Integer.parseInt(number1.getText().toString());
                     sum += num1;
                    f1=false;
                } else {
                    Toast errorToast = Toast.makeText(MainActivity.this, "Please give me a first number", Toast.LENGTH_SHORT);
                    errorToast.show();
                        break;
                }
                if (!(number2.getText().toString().trim().equals(""))) {
                    num2= Integer.parseInt(number2.getText().toString());
                    sum += num2;
                    f2=false;
                } else {
                    Toast errorToast = Toast.makeText(MainActivity.this, "Please give me a second number", Toast.LENGTH_SHORT);
                    errorToast.show();
                    break;
                }

            }
        //number1 = findViewById(R.id.first);
        //number2 = findViewById(R.id.second);

          //sum = num1 + num2;

            //result = findViewById(R.id.result);
            //result.setText(String.valueOf(sum));

            //result.setText(String.valueOf(sum));
            // Intent intent = new Intent(view.getContext(), add.class);
            //intent.putExtra("message",String.valueOf(sum));

            //tartActivity(intent);

     if((!f1)&&(!f2)) {
         Intent intent = new Intent(MainActivity.this, add.class);
         intent.putExtra("message", String.valueOf(sum));
         this.startActivity(intent);

     }
        }



    public void reset (View view){
            number1.setText("0");
            number2.setText("0");
        }
    public void information(View v){
        Intent intent = new Intent(MainActivity.this, information.class);
        intent.putExtra("message","");
        this.startActivity(intent);
    }

}