package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class information extends AppCompatActivity {
    TextView information;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);
        information=findViewById(R.id.textView2);
        information.setText("This is an app calculator in which you can type 2 numbers and see the sum of these two numbers." +
                "Also by clicking the button 'reset' the two numbers automatically get the value '0' ");


    }
    public void back(View view){
        Intent intent= new Intent(information.this,MainActivity.class);
        intent.putExtra("message","");
        this.startActivity(intent);
    }
}