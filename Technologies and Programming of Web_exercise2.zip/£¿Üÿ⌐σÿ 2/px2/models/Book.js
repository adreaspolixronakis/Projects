
class Book{
    constructor(_title,_id,_author,review){
        this.title=_title;
        this.id=_id;
        this.author=_author;
        this.review="Δεν υπάρχει καμία κριτική"
    }
    //Getters
    get get_title(){
        return this.title;
    }
    get get_id(){
        return this.id;
    }
    get get_author(){
        return this.author;
    }
    get get_arrayBooks(){
        return this.arrayBooks;
    } 

    get get_review(){
        return this.review
    }

    //Setters
    set_title(_title){
        this.title=_title;
    }
    set_id(_id){
        this.id=_id;
    }
    set_author(_author){
        this.author=_author;
    } 
    set_review(_review){
        this.review=_review;
    }

    saveBook(){
        const title=this.title;
        const author=this.author;
        const id=this.id;
    }
}
module.exports = Book