const Book=require('./Book.js');
var array=new Array();
class Work {
    get get_ArrayBook(){
        return array;
    }
    addbook(title,id,author){
        var i;
        var book;
        if(array.length <1){
            book = new Book(title,id,author);
            array.push(book)
           return true
        }else{
            for(i=0;i<array.length;i++){
                var j=0;
                if(id == array[i].id){
                    j=j+1
                    return false
                    
                   // break;
                }
            }
            if(j==0){
                book = new Book(title,id,author);
                array.push(book)
                return true
            }
        }
    }
    //delete
    delete(id){
        if(array.length==0){
            return false
           }else{
               var i;
               for(i=0;i<array.length;i++){
                   var j=0;
                   if(id==array[i].id){
                       j=j+1;
                       //response.status(201).send("the book with id :"+request.body["id"]+" deleted")
                       array.splice(i,1)
                       return true;
                   }
               }
               if(j==0){
                //response.status(401).send("book not found")
                return false;
               }
           }
    }
    deletefavorites(title){
        var i;
   for(i=0;i<array.length;i++){
       if(title ==array[i].title){
        array.splice(i,1)
        return true;
        //response.status(201).send("the book with id :"+request.body["id"]+" deleted")
       }
   
    }

}

    edit_function(title,id,author,review){
    var i;
    //console.log(title)
    //console.log(author)
    //console.log(array.length)
    for(i=0;i<array.length;i++){
        if(array[i].id == id){
            //console.log(array[i].id)
            array[i].set_title(title)
            array[i].set_author(author)
            array[i].set_review(review)
        }
    }
    }


}
module.exports = Work