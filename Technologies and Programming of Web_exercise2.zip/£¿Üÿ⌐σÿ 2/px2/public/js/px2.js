
function indexmain(){
//EventListener

document.getElementById('addPost').addEventListener('submit', addPost);

}

   

function addPost(e){
    var j=0;
     e.preventDefault();
     let title = document.getElementById('title').value;
     let limit=document.getElementById('limit').value
     var url0="https://reststop.randomhouse.com/resources/works?start=0&max="
     var url1=url0.concat(limit)
     var url2=url1.concat('&')
     var url3=url2.concat('search=')
     var finalurl=url3.concat(title)
     console.log(finalurl)
     let myHeaders=new Headers();
     myHeaders.append('Accept','application/json')
     let init={
         method:"GET",
         headers:myHeaders
     }

    fetch(finalurl,init)
    .then((res) => res.json())
     .then((data) => {  
       if(data.work !=null){
           let output = '<h2>TITLES</h2>';
           for(i=0;i<data.work.length;i++){
               var string=data.work[i].titleweb
               var final=title
               console.log(final)
              if((string.toUpperCase().includes(final.toUpperCase()))){
                var saveid="save_"+data.work[i].workid
                var deleteid="del_"+data.work[i].workid
                var id=data.work[i].workid
                var author=data.work[i].authorweb
                  j++
               output += `
                   <nav>
                   <h3>Title of the book:${data.work[i].titleweb}</h3>
                   <p>Author :${author}</p>
                   <p>ID:${id}</p>
                   <input type="image" src="save.png" class="button" id="${saveid}" onclick="button_save(${id},'${author}','${data.work[i].titleweb}')"></button>
                   <input type="image" src="delete.png" class="button" id="${deleteid}" onclick="button_delete(${id},'${author}','${data.work[i].titleweb}')"></button>
                   </nav>
                    `
                   ;
                }
           }
           var results=j+' results have been found <br>'
           document.getElementById('results').innerHTML =results;
           document.getElementById('output').innerHTML =output;

        }else{
           document.getElementById('output').innerHTML ="The book that you searched does not exist try again";
       }
       
   
  
     
      
    
   })
   .catch(error =>{
       console.log(error)
   })
       
}

//------------------------------------------------------------------------------//
//ΠΧ2

function button_save(id,author,title_book){
   // var object={title:title_book ,author:author,id:id}
    //var objjson=JSON.stringify(object)
   // console.log(title_book)
    sendInfo(id,author,title_book)
}
function button_delete(deleteid,author,title_book){
   deletejson(deleteid,author,title_book);
}

function sendInfo(id,author,book){
    var obj={title:book,id:id,author:author};
    var myJSON=JSON.stringify(obj)
    const options={
        method:"Post",
        headers:{"Content-Type":"application/json"},
        body:myJSON 
    }
    fetch("http://localhost:8080/save",options)
    .then(response => {
        if(response.status===201){
            document.getElementById("results").innerHTML="Added the book with id :"+id
            favoriteTitles();
        }else if (response.status===400){
            document.getElementById("results").innerHTML="Duplicate : "+id
            
        }
    })
    
}

function deletejson(id,author,title){
    var obj={id:id,author:author,title:title};
    var objjson=JSON.stringify(obj)
    console.log(id)

    const options={
        method:'DELETE',
        headers:{"Content-Type":"application/json"},
        body:objjson
    }
    fetch("http://localhost:8080/delete",options)
    .then(response => {
        if(response.status===201){
            document.getElementById("results").innerHTML ="The book with the id : "+id+" deleted"
            
        }else if (response.status===400){
            document.getElementById("results").innerHTML ="you must save a title first"
            

        }else if (response.status===401){
            document.getElementById("results").innerHTML ="The book not found"
            

        }
    })
}

function favoriteTitles(){
    const options={
        method:"GET",
        headers:{"Content-Type":"application/json"},
    }
    fetch("http://localhost:8080/array",options)
    .then(response => response.json())
    .then(data =>{
        var i;
       
        var output='';
        for(i=0;i<data.length;i++){
            var review=data[i].review
            output += ` 
            Tίτλος Bιβλίου:${data[i].title}<br>
            Συγγραφέας:${data[i].author}<br>
            ID:${data[i].id}<br>
            Κριτική:${review}<br>
            <br>
            <input type="image" src="delete.png" class="button" onclick="deletefavorites('${data[i].title}')"></button>
            <input type="image" src="edit.png" class="button" onclick="edit('${data[i].id}')"></button> 
            <br>
            <br>
            `
        
                   ;
        }
            if(document.getElementById("demo")!= null){
                document.getElementById("demo").innerHTML=output
            }
        
        if(output===""){
            document.getElementById("demo").innerHTML="Η λίστα είναι κενή.Για να προσθέσετε κάποιο βιβλίο πατήστε στην αναζήτηση το βιβλίο που επιθυμείτε" 
        }
        
    })
}
function deletefavorites(title){
    var obj={title:title};
    var objjson=JSON.stringify(obj)

    const options={
        method:'DELETE',
        headers:{"Content-Type":"application/json"},
        body:objjson
    }
    fetch("http://localhost:8080/titlefavorites",options)
    .then(response => {
        if(response.status===201){
           favoriteTitles()//gia na enimerosi thn lista afou enimerothike apo to delete
        }
    })
}

function addtitle(e){
    var j=0;
     e.preventDefault();
     let title = document.getElementById('title').value;
     let limit=document.getElementById('limit').value
     var url0="https://reststop.randomhouse.com/resources/works?start=0&max=5&"
     var url1=url0.concat(limit)
     var url2=url1.concat('&')
     var url3=url2.concat('search=')
     var finalurl=url3.concat(title)
     console.log(finalurl)
     let myHeaders=new Headers();
     myHeaders.append('Accept','application/json')
     let init={
         method:"GET",
         headers:myHeaders
     }

     fetch(finalurl,init)
     .then((res) => res.json())
     .then((data) => {  
       if(data.work !=null){
           let output = '<h2>TITLES</h2>';
           
           
           for(i=0;i<data.work.length;i++){
               var string=data.work[i].titleweb.toUpperCase()
               var final=title.toUpperCase();
              
              if((string.includes(final))){
                var saveid="save_"+data.work[i].workid
                var deleteid="del_"+data.work[i].workid
                var id=data.work[i].workid
                var author=data.work[i].authorweb
                  j++
               output += `
                   <nav>
                   <h3>Title of the book:${data.work[i].titleweb}</h3>
                   <p>Author :${author}</p>
                   <p>ID:${id}</p>
                   <button id="${saveid}" onclick="button_save(${saveid},${deleteid},${id},'${author}','${data.work[i].titleweb}')">Αποθήκευση</button>
                   <button id="${deleteid}" onclick="button_delete(${id},'${author}','${data.work[i].titleweb}')">Διαγραφή</button>
                   </nav>
                    `
                   ;
                }
           }
           var results=j+' results have been found <br>'
           document.getElementById('results').innerHTML =results;
           document.getElementById('output').innerHTML =output;

        }else{
           document.getElementById('output').innerHTML ="The book that you searched does not exist try again";
       }
       
   
   
     
      
    
   })
   .catch(error =>{
       console.log(error)
   })
}




function filter(){
    document.getElementById("demo").innerHTML="Loading...."
    myVar=setTimeout(filterbook,1000)
}

function filterbook(){
    //console.log(document.getElementById("searchlist").value)
    const options={
        method:"GET",
        headers:{"Content-Type":"application/json"}
    }
    fetch("http://localhost:8080/array",options)
    .then(response => response.json())
    .then(data =>{
        var output1=" "
        var k=0;
        var key=document.getElementById("word").value
       console.log(key)
        //document.getElementById("searchlist").style.display=" "
        for(i=0;i<data.length;i++){
            var id=data[i].id
            var author=data[i].author
            if(data[i].title.toUpperCase().includes(key.toUpperCase())){
                k=k+1;
                output1 += `
                   <nav>
                   <h3>Title of the book:${data[i].title}</h3>
                   <p>Author :${author}</p>
                   <p>ID:${id}</p>
                   <input type="image" src="delete.png" class="button" onclick="deletefavorites('${data[i].title}')"></button>
                   <input type="image" src="edit.png" class="button" onclick="edit('${data[i].id}')"></button> 
                   <br>
                   <br>
                   </nav>
                    `
                   ;
                  
            }
           //if(key ==''){
           // output1=''
           //}
            
        }
        if(k>0){
            document.getElementById("demo").innerHTML=output1
        }else{
            document.getElementById("demo").innerHTML="The book that you searched does not exist"
        }

        
       
    })
    


}


function edit(id){
    window.location.href='/static/edit.html'//epistrefei to url tis edit.html kai kanei redirect ton browser se ayth thn selida
    localStorage.setItem("id",id)
}

function editBook(){
    const options={
        method:"GET",
        headers:{"Content-Type":"application/json"},
    }
    fetch("http://localhost:8080/array",options)
    .then(response => response.json())
    .then(data =>{
        var i;
        for(i=0;i<data.length;i++){
            if(data[i].id==localStorage.getItem("id")){
            document.getElementById("id").value=data[i].id
            document.getElementById("author").value=data[i].author
            document.getElementById("title").value=data[i].title
            }
        }
        

});
}

function save_changes(id){
  var new_title=document.getElementById("title").value
  var new_author= document.getElementById("author").value
  var review=document.getElementById("review").value
  var obj1={title:new_title,author:new_author,id:id,review:review};
    var objectjson=JSON.stringify(obj1)
    const options={
        method:"Post",
        headers:{"Content-Type":"application/json"},
        body:objectjson
    }
    fetch("http://localhost:8080/changes",options)
    .then(response => response.json())
    

}
var title=document.getElementById("title")
if(title !=null){
title.addEventListener('input',()=>{
    title.setCustomValidity('');
    title.checkValidity();
  });

  
  title.addEventListener('invalid',()=>{
    if(title.value===''){
      title.setCustomValidity("Δώστε τον τίτλο του βιβλίου που επιθυμείτε");
    }else{
      title.setCustomValidity("");
  
    }
});
}

var limit=document.getElementById("limit")
if(limit !=null){
limit.addEventListener('input',()=>{
    limit.setCustomValidity('');
    limit.checkValidity();
  });
  
  limit.addEventListener('invalid',()=>{
    if(limit.value===''){
      limit.setCustomValidity("Ορίστε το όριο των βιβλίων που θέλετε να κάνετε αναζήτηση.Αν θέλετε να κάνετε αναζήτηση από όλα τα διαθέσιμα βιβλία πατήστε το μηδέν(0)");
    }else{
      limit.setCustomValidity("");
  
    }
});
}




    






