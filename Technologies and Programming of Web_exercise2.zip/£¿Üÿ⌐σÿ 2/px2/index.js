const Book=require('./models/Book');
const Work=require('./models/Work.js')
const express = require('express')//eisagogi express module
const path = require('path')
const app = express()//dimiourgia express efarmogis
const port = 8080

app.listen(port)//ekkinisi efarmogis stin thira 8080

var options={
    root:path.join(__dirname, 'public')
}
/* 
    Serve static content from directory "public",
    it will be accessible under path /static, 
    e.g. http://localhost:8080/static/index.html
*/
app.use('/static', express.static(__dirname + '/public'))//exipiretisi statikoy periexomenou,to /static ->to prothema ton aitimaton gia statikous porous

// parse url-encoded content from body
app.use(express.urlencoded({ extended: false }))

// parse application/json content from body
app.use(express.json())

app.use(express.static(__dirname + '/public'));

// serve index.html as content root
app.get('/', function(req, res){

    var options = {
        root: path.join(__dirname, 'public')
    }

    res.sendFile('index.html', options, function(err){
        console.log(err)
    })
})
app.post('/favorites', function(req, res){

    var options = {
        root: path.join(__dirname, 'public')
    }

    res.sendFile('favorites.html', options, function(err){
        console.log(err)
    })
})
app.get('/favorites', function(req, res){

    var options = {
        root: path.join(__dirname, 'public')
    }

    res.sendFile('favorites.html', options, function(err){
        console.log(err)
    })
})






var array=new Array()
var work=new Work();
console.log("a")
app.post('/save',function(request,response){
    var result=work.addbook(request.body['title'],request.body['id'],request.body['author']);
    if(result){
        response.status(201).send("Added"+request.body['id'])
    }else{
        response.status(400).send('DUPLICATE'+request.body['id'])
    }
})
console.log("b")
app.delete('/delete',function(request,response){
   var deletemsg=work.delete(request.body["id"])
   if(deletemsg){
    response.status(201).send("the book with id :"+request.body['id']+"deleted")
   }else{
    response.status(401).send("book not found")
   }
})

app.get('/array',function(request,response){
    var newarray=JSON.stringify(work.get_ArrayBook);
    response.send(newarray);
})

app.delete('/titlefavorites',function(request,response){
   var deletefav=work.deletefavorites(request.body["title"])
   if(deletefav){
    response.status(201).send("the book with id :"+request.body["id"]+" deleted")
   }
})

app.post('/changes',function(request,response){
    work.edit_function(request.body['title'],request.body['id'],request.body['author'],request.body['review'])
})




    
    




console.log('Server started! At http://localhost:' + port);