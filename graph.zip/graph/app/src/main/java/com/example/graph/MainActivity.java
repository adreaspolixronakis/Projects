package com.example.graph;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

LineGraphSeries<DataPoint> series;
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GraphView graph =findViewById(R.id.graph);
        try {
            series=new LineGraphSeries<>(getDataPoint());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        graph.addSeries(series);
        graph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){

            @Override
            public String formatLabel(double value, boolean isValueX) {
                if(isValueX){
                    return sdf.format(new Date((long) value));
                }else {
                    return super.formatLabel(value, isValueX);
                }
            }
        });

        graph.getGridLabelRenderer().setNumHorizontalLabels(14);
        graph.setTitle("GRAPH-VIEW");
        series.setColor(Color.BLACK);//color of the serie
        graph.getViewport().setXAxisBoundsManual(false);
        GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
        //gridLabel.setHorizontalAxisTitle("DATE");
        graph.getViewport().setScalable(true);
        graph.getViewport().setScrollable(true);
        GridLabelRenderer renderer = graph.getGridLabelRenderer();
        renderer.setHorizontalLabelsAngle(90);
        renderer.setLabelsSpace(30);
        //renderer.setTextSize(50);
        renderer.setPadding(40);
        renderer.setHorizontalAxisTitleColor(Color.BLACK);
        graph.getGridLabelRenderer().setHumanRounding(false);
        graph.getViewport().setMaxY(14);
    }

    private DataPoint[] getDataPoint() throws ParseException {
        //sdf=new SimpleDateFormat("dd/MM/yyyy");
        String date1="05/05/2021";
        Date newDate1=sdf.parse(date1);
        String date2="06/06/2021";
        Date newDate2=sdf.parse(date2);
        String date3="08/07/2021";
        Date newDate3=sdf.parse(date3);
        String date4="15/07/2021";
        Date newDate4=sdf.parse(date4);
        String date5="20/08/2021";
        Date newDate5=sdf.parse(date5);
        String date6="10/10/2021";
        Date newDate6=sdf.parse(date6);
        String date7="10/11/2021";
        Date newDate7=sdf.parse(date7);
        String date8="15/11/2021";
        Date newDate8=sdf.parse(date8);
        String date9="20/12/2021";
        Date newDate9=sdf.parse(date9);
        String date10="20/01/2022";
        Date newDate10=sdf.parse(date10);
        String date11="20/10/2022";
        Date newDate11=sdf.parse(date11);



        DataPoint[] dp=new DataPoint[]{
                 new DataPoint(newDate1,10),
                 new DataPoint(newDate2,9),
                 new DataPoint(newDate3,8),
                 new DataPoint(newDate4,9),
                 new DataPoint(newDate5,12),
                 new DataPoint(newDate6,14),
                 new DataPoint(newDate7,4),
                 new DataPoint(newDate8,6),
                 new DataPoint(newDate9,10),
                 new DataPoint(newDate10,14),
                 new DataPoint(newDate11,8),

        };
        return dp;
    }


}