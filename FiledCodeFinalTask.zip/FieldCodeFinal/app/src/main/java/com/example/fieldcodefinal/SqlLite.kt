
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

import android.database.sqlite.SQLiteOpenHelper
import android.provider.ContactsContract


class SampleSQLiteDBHelper(context: Context?) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
        sqLiteDatabase.execSQL(
            "CREATE TABLE " + PERSON_TABLE_NAME+ " (" +
                    PERSON_COLUMN_ID + " INTEGER PRIMARY KEY, " +
                    PERSON_COLUMN_TITLE + " TEXT, " +
                    PERSON_COLUMN_DESCRIPTION + " TEXT, " +
                    PERSON_COLUMN_USER_ID+ "INTEGER "+
                    ")"
        )
    }

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, i: Int, i1: Int) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + PERSON_TABLE_NAME)
        onCreate(sqLiteDatabase)
    }

    companion object {
        private const val DATABASE_VERSION =3
        const val DATABASE_NAME = "sample_database"
        const val PERSON_TABLE_NAME = "person"
        const val PERSON_COLUMN_USER_ID = "userid"
        const val PERSON_COLUMN_ID = "id"
        const val PERSON_COLUMN_TITLE = "title"
        const val PERSON_COLUMN_DESCRIPTION = "description"
    }
     fun getName(): Cursor? {

        // here we are creating a readable
        // variable of our database
        // as we want to read value from it
        val db = this.readableDatabase

        // below code returns a cursor to
        // read data from the database
        return db.rawQuery("SELECT * FROM " + PERSON_TABLE_NAME, null)

    }
}


