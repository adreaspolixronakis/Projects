package com.example.fieldcodetask

import SampleSQLiteDBHelper
import android.annotation.SuppressLint
import android.content.ContentValues
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.fieldcodefinal.R
import org.json.JSONArray
import java.io.*
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.ProtocolException
import java.net.URL


class MainActivity : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lateinit var button: Button;
        button = findViewById(R.id.getbutton)
        button.setOnClickListener {
            AsyncTaskHttpGet().execute("https://jsonplaceholder.typicode.com/posts");
        }

    }

    inner class AsyncTaskHttpGet : AsyncTask<String, String, String>() {
        override fun doInBackground(vararg url: String?): String {
            var text: String;
            val connection = URL("https://jsonplaceholder.typicode.com/posts").openConnection() as HttpURLConnection;
            try {
                connection.connect();
                text =
                    connection.inputStream.use { it.reader().use { reader -> reader.readText() } }
            } finally {
                connection.disconnect();
            }
            return text;
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            handleJson(result);
        }

    }

    private fun handleJson(jsonstring: String?) {
        val jsonArray = JSONArray(jsonstring);
        Log.i("pinakas", jsonArray.toString());
        //val values=Array<String>(4*jsonArray.length(),{i ->"result"});
        var x = 0;
        var itemsLayout: LinearLayout = findViewById(R.id.hiddengetlayout);
        itemsLayout.removeAllViewsInLayout();
        itemsLayout.removeAllViews();
        while (x < jsonArray.length()) {
            val view = layoutInflater.inflate(R.layout.hiddenget, null)

            itemsLayout.addView(view)
            val titlebook: EditText = view.findViewById(R.id.title);
            val description: EditText = view.findViewById(R.id.description);
            val Jsonobject = jsonArray.getJSONObject(x);
            val userid = Jsonobject.getInt("userId");
            val id = Jsonobject.getInt("id");
            val title = Jsonobject.getString("title");
            val body = Jsonobject.getString("body");
            titlebook.id = 1000 + x
            titlebook.setText(title);
            description.setText(body);
            description.id = 2000 + x;
            val iduser: Int;
            iduser = userid;
            x = x + 1;
            lateinit var buttonnew: Button;
            buttonnew = findViewById(R.id.newbutton)
            buttonnew.id = 5000 + x;
            val view3: LinearLayout = findViewById(R.id.newresource);
            view3.id=8000+x;
            buttonnew.setOnClickListener {
                var newtitlebool: Boolean;
                var newdescriptionbool: Boolean;
                Log.i("mpika", "nai");
                view3.visibility = View.VISIBLE;
                val view = layoutInflater.inflate(R.layout.newresource, null);
                view.id=4000+x;
                view3.addView(view)

                var newtitle: EditText = view3.findViewById(R.id.titlenew);
                newtitle.id=5000+x;
                if (newtitle.text.toString().equals("")) {
                    newtitlebool = false;
                } else {
                    newtitlebool = true;
                }
                    var newdescription: EditText = view3.findViewById(R.id.descriptionnew);
                newdescription.id=5000+x;
                    if (newdescription.text.toString().equals("")) {
                        newdescriptionbool = false;
                    } else {
                        newdescriptionbool = true;
                    }
                    if (!newdescriptionbool || !newtitlebool) {
                        Toast.makeText(this, "Please complete all the fields", Toast.LENGTH_SHORT)
                            .show()
                    }
                Log.i("mpika edo","nai");
                lateinit var buttonnew: Button;
                buttonnew =view3.findViewById(R.id.savenewresource)
                buttonnew.id = 8000 + x;
                buttonnew.setOnClickListener{
                    if (newtitle.text.toString().equals("") ||newdescription.text.toString().equals("")) {
                        Toast.makeText(this, "Please complete all the fields", Toast.LENGTH_SHORT)
                            .show()
                    }else {
                        AsyncTaskPost().execute(
                            "https://jsonplaceholder.typicode.com/posts",
                            userid.toString(),
                            newtitle.text.toString(),
                            newdescription.text.toString()
                        );
                    }
                    }
            }
            lateinit var delete: Button;
            delete = findViewById(R.id.delete)
            delete.id = 6000 + x;
            delete.setOnClickListener{
                Log.i("mpika delete","nai");
                AsyncTaskDelete().execute(
                   "https://jsonplaceholder.typicode.com/posts/$userid",
                    iduser.toString()
                );
                //deletedb(id);
            }
            lateinit var buttonsave: Button;
            buttonsave = findViewById(R.id.save)
            buttonsave.id = 5000 + x;
            buttonsave.setOnClickListener{
                save(title,body);
                //readFromDB(title,userid,id,body)
            }

        }
    }

    //private fun deletedb(id: Int) {
      //  val database = SampleSQLiteDBHelper(this).writableDatabase
      //  database.delete(PERSON_TABLE_NAME, PERSON_COLUMN_USER_ID+ "=" + id, null)
      //  Toast.makeText(this, "The row with id $id deleted", Toast.LENGTH_LONG).show()
   // }

    private fun save(title:String,description:String) {

        val database = SampleSQLiteDBHelper(this).writableDatabase
        val values = ContentValues()


        values.put(
            SampleSQLiteDBHelper.PERSON_COLUMN_TITLE,
            title
        )
        values.put(
            SampleSQLiteDBHelper.PERSON_COLUMN_DESCRIPTION,
            description
        )


        val newRowId = database.insert(SampleSQLiteDBHelper.PERSON_TABLE_NAME, null, values)
        Toast.makeText(this, "The new Row Id is $newRowId", Toast.LENGTH_LONG).show()
    }


    inner class AsyncTaskPost : AsyncTask<String?, Void?, String>() {
        override fun onPreExecute() {
            //display progress dialog.
        }

        override fun onPostExecute(result: String) {
            if (result == "1003") {
                Toast.makeText(getApplicationContext(), "There is an error occured.Please check your internet connection", Toast.LENGTH_LONG)
                    .show();
            } else {
                Toast.makeText(getApplicationContext(), "SAVE SUCCESFULL", Toast.LENGTH_LONG)
                    .show();
               // AsyncTaskHttpGet().execute("https://jsonplaceholder.typicode.com/posts");
            }
        }

        override fun doInBackground(vararg p0: String?): String {
            val url: URL
            try {
                //URL url = new URL("https://bfqditgs.p50.weaved.com/savefarmaka.php?value-1=1&value-2=1&value-3=%272016-06-30%2012:00:00%27&value-4=%272016-07-30%2012:00:00%27&value-5=30&value-6=1&value-7=1&value-8=null&value-9=null&value-10=1");
                url = URL(p0[0])
                Log.i("url post", url.toString())
            } catch (e: MalformedURLException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
                return "1003"
            }
            val conn: HttpURLConnection
            conn = try {
                url.openConnection() as HttpURLConnection
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
                return "1003"
            }
            conn.doOutput = true
            conn.allowUserInteraction = false
            try {
                conn.requestMethod = "POST"
            } catch (e: ProtocolException) {
                e.printStackTrace()
            }
            var title=p0[2];
            var description=p0[3];
            var id=p0[1];
            val parameters = """{
                      "title":$title,
                       "body":$description,
                       "userId":$id
                       }"""
            Log.i("tiegine", parameters)
            var writer: OutputStreamWriter? = null
            try {
                writer = OutputStreamWriter(conn.outputStream)
            } catch (e: IOException) {
                e.printStackTrace()
            }
            try {
                writer!!.write(parameters)
            } catch (e: IOException) {
                e.printStackTrace()
            }
            try {
                writer!!.flush()
            } catch (e: IOException) {
                e.printStackTrace()
            }
            try {
                conn.connect()
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
                return "1003"
            }
            //     conn.setDoOutput(true);
            var `in`: InputStream? = null
            `in` = try {
                conn.inputStream
                //  in = conn.openStream();
            } catch (e: IOException) {
                e.printStackTrace()
                return "1003"
            }
            val bis = BufferedInputStream(`in`)
            var br: BufferedReader? = null
            val sb = StringBuilder()
            var line: String?
            try {
                br = BufferedReader(InputStreamReader(`in`))
                while (br.readLine().also { line = it } != null) {
                    sb.append(line)
                }
            } catch (e: IOException) {
                e.printStackTrace()
                return "1003"
            } finally {
                if (br != null) {
                    try {
                        br.close()
                    } catch (e: IOException) {
                        e.printStackTrace()
                        return "1003"
                    }
                }
            }
            val result2:String;
            conn.disconnect()
            result2 = sb.toString()
            return result2
        }
    }
    inner class AsyncTaskDelete : AsyncTask<String?, Void?, String>() {
        override fun onPreExecute() {
            //display progress dialog.
        }

        override fun onPostExecute(result: String) {
            if (result == "1003") {
                Toast.makeText(getApplicationContext(), "There is an error occured.Please check your internet connection", Toast.LENGTH_LONG)
                    .show();
            } else {
                Log.i("SUCCESFULL DELETE",result);
                AsyncTaskHttpGet().execute("https://jsonplaceholder.typicode.com/posts");
            }
        }

        override fun doInBackground(vararg p0: String?): String {
            val url: URL
            try {
                //URL url = new URL("https://bfqditgs.p50.weaved.com/savefarmaka.php?value-1=1&value-2=1&value-3=%272016-06-30%2012:00:00%27&value-4=%272016-07-30%2012:00:00%27&value-5=30&value-6=1&value-7=1&value-8=null&value-9=null&value-10=1");
                url = URL(p0[0])
                Log.i("url post", url.toString())
            } catch (e: MalformedURLException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
                return "1003"
            }
            val conn: HttpURLConnection
            conn = try {
                url.openConnection() as HttpURLConnection
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
                return "1003"
            }
            conn.doOutput = true
            conn.allowUserInteraction = false
            try {
                conn.requestMethod = "DELETE"
            } catch (e: ProtocolException) {
                e.printStackTrace()
            }

            var writer: OutputStreamWriter? = null
            try {
                writer = OutputStreamWriter(conn.outputStream)
            } catch (e: IOException) {
                e.printStackTrace()
            }
            try {
                writer!!.flush()
            } catch (e: IOException) {
                e.printStackTrace()
            }
            try {
                conn.connect()
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
                return "1003"
            }
            //     conn.setDoOutput(true);
            var `in`: InputStream? = null
            `in` = try {
                conn.inputStream
                //  in = conn.openStream();
            } catch (e: IOException) {
                e.printStackTrace()
                return "1003"
            }
            val bis = BufferedInputStream(`in`)
            var br: BufferedReader? = null
            val sb = StringBuilder()
            var line: String?
            try {
                br = BufferedReader(InputStreamReader(`in`))
                while (br.readLine().also { line = it } != null) {
                    sb.append(line)
                }
            } catch (e: IOException) {
                e.printStackTrace()
                return "1003"
            } finally {
                if (br != null) {
                    try {
                        br.close()
                    } catch (e: IOException) {
                        e.printStackTrace()
                        return "1003"
                    }
                }
            }
            val result2:String;
            conn.disconnect()
            result2 = sb.toString()
            return result2
        }
    }


}