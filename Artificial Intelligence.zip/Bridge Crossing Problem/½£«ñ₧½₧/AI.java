import java.util.ArrayList;

public interface AI {
	
	public void solve();

}
