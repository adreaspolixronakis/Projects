gcc p3170140-p3170160-p3170118-res1.c -lpthread
./a.out 100 1000